﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ATM_Practice
{
    public partial class AccountList : Form
    {
        public AccountList()
        {
            InitializeComponent();
            Hide();
        }

        private void AccountListItem6_Click(object sender, EventArgs e)
        {

        }

        private void AccountListItem5_Click(object sender, EventArgs e)
        {

        }

        private void AccountListItem4_Click(object sender, EventArgs e)
        {

        }

        private void AccountListItem3_Click(object sender, EventArgs e)
        {

        }

        private void AccountListItem2_Click(object sender, EventArgs e)
        {

        }

        private void AccountListItem1_Click(object sender, EventArgs e)
        {

        }
    }
}
